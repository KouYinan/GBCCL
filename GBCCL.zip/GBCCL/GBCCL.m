%% 粒球分裂(球心，半径，纯度)



clc;clear 
load wine.mat;
data=wine;
[n_row,n_col] = size(data);

%% 划分测试集和训练�?
[n_row,n_col]=size(data); %m�������Ը���
label=unique(data(:,n_col));%Ԫ��ȥ�ء�����ɾ�����������������ڵ��ظ�Ԫ��(ֻ����һ��)���˴���ɾ�������������ɾ��������ָ�ظ�Ԫ�ص�λ�ñ����ظ���Ԫ�ظ�ռ����(
 data(:,1:n_col-1)=mapminmax(data(:,1:n_col-1)',0,1)'; %��һ������ģ��-������ʽ����
C=length(label); %������
indices = crossvalind('Kfold',n_row,10);
tic;
for t=1:10
    tic;
    k_=t;
test=(indices==k_);
train=~test;
train_data=data(train,:);
datatest = data(test,:);
test=datatest(:,1:end-1);

F =train_data;%训练�?
[row,column]=size(F);
x_label=unique(F(:,end));
p = size(x_label,1);
labeli= F(:,end);
%% 对象粒概念，属�?�粒概念
T=0;  tic;
x_ex=zeros(row,row);%a_intent=[];a_ex=cell(column-1,1);
x_intent=F(:,1:end-1);%对象粒内�?
pur=zeros(1,row);
for i=1:row
     B = repmat(x_intent(i,:)',1,row);
     s = B'-x_intent;
     x_ex(i,find(all(s'<=0)))=1 ;%对象粒外�?
     l_con=labeli(find(all(s'<=0)));
     pur(i)=length(find(l_con==mode(l_con)))/length(l_con);
end
L=zeros(row,p);
for i=1:p
    L(find(labeli==i),i)=1;
end


%% 判断纯度，粒球分�?

       fenlie=find(pur<1);
       gengxin=x_ex(fenlie,:);
       gbs1=[];sampleed=zeros(1,row);gbs2=[];cun=[];gbs=[];
 for i=1:length(fenlie)
          
          if length(find(gengxin(i,:)==1))==2
             cun=repmat(gengxin(i,:),p,1)+L';
          cun(find(cun<2))=0;cun(find(cun==2))=1;
          gbs1=[gbs1;cun];
          else
          goal=find(gengxin(i,:)==1);goal_=goal;
          x_m=x_intent(goal,:);k=length(unique(labeli(find(gengxin(i,:)==1))));
          n=1;
         while length(goal_)>0 %|| n<50   %length(find(sum(gbs2)==gengxin(i,:))==1)<row
          
              for j=1:k%类别
 
                   [idx,C,sumd,D]=kmeans(x_m,2,'Replicates',2,"Display","final");
                     if j>length(unique(idx))
                         r=sumd(length(unique(idx)),:)*1/sum(idx==length(unique(idx)));%每个类别的半�?
                         center=C(length(unique(idx)),:);%每簇的簇�?
                         index=goal(find(D(:,length(unique(idx)))<=r));
                     else
                         r=sumd(j,:)*1/sum(idx==j);%每个类别的半�?
                         center=C(j,:);%每簇的簇�?
                         index=goal(find(D(:,j)<=r));
                     end
                     if length(index)==0 
                         index=goal_;
                     end
                   
                 %sample=find(D(:,j)<=r);%sampleed(find(gengxin(i,:)==1))==1;ori=gengxin(i,:)-sampleed;
                 x_l=labeli(index);%颗粒球内的标�?
                 b=mode(x_l);%颗粒球内标签占比�?大的标签
                 %m=labeli(goal);
                 true=index;goal_=goal_(~ismember(goal_,true));
                % x_m=x_intent(goal,:);
                 purity=length(find(x_l==b))/length(x_l);%颗粒球的纯度
                    if purity==1||r<0.2
                        sampleed(index)=1;
                       gbs2=[gbs2;sampleed];
                       sampleed=zeros(1,row); 
                   break
                   else 
                     k=length(unique(labeli(true)));
                     x_m=x_intent(true,:);
                        %m_label=labeli(m);
                        if length(true)==2
                            sampleed(index)=1;
                             gbs2=[gbs2;sampleed];sampleed=zeros(1,row); 
                             break 
                        end
                   continue     
                    end
                    Xu= randperm(size(x_m,1));%数据打乱得到随机�?                   
                    x_m =x_m(Xu,:);
              end 
              gbs2=unique(gbs2,'rows');n=n+1;
              if n>30
                  break
              end
          end
         
          end
          gbs=[gbs2;cun;gbs1];
 end         

%% 分裂完成后求内涵
      gbs=unique(gbs,'rows');
       x_ex(fenlie,:)=[];x_ex=[gbs;x_ex];
       x_ex(all(x_ex==0,2),:)=[];
       row_ex=length(x_ex(:,1));
       biaoji=x_ex*L;ind=ones(row_ex,1);
       for i=1:row_ex
           if length(find(biaoji(i,:)>0))>1;
              ind(i)=0;
           end
       end
biaoji=biaoji.*ind;x_ex=x_ex.*ind;x_ex(all(x_ex==0,2),:)=[];biaoji(all(biaoji==0,2),:)=[];
for i=1:length(x_ex(:,1))
      
    label_end(i)=find(biaoji(i,:)>0);
     
      if sum(x_ex(i,:))>1
            intent_end(i,:)=min(x_intent(find(x_ex(i,:)==1),:)); %属�?�粒内涵
            %Bf{i}(j,:)=min(Ac{i}(X{i,j},1:m0-1)); 
        else  
            intent_end(i,:)=x_intent(find(x_ex(i,:)==1),:);
            %Bf{i}(j,:)=Ac{i}(X{i,j},1:m0-1); 
      end
end
%% 概念预测

[na,~]=size(datatest);%time=10;
label_true =datatest (:,end);predict_label= [];d1=[];

 for i=1:na 
     d1=pdist2(test(i,:),intent_end,'euclidean'); sigma=median(d1); 
     K=exp(-pdist2(test(i,:),intent_end,'euclidean')/(2*sigma^2));
     c2=find(K==max(K));
%                
%            c2=find(d1==min(d1));
     predict_label(i,1)=label_end(c2(1));
 end
pre_true = length(find((predict_label)==label_true));
accuracy= (pre_true/na)*100;
toc;T=T+toc;

Time(t)=toc;

 M=confusionmat(label_true,predict_label);
 precision=diag(M)./(sum(M,2));
 recall=diag(M)./(sum(M,1))';
 precision=mean(precision);
 recall=mean(recall);
 F1=2*(precision*recall)/(precision+recall);
 t_acc(t)=accuracy; 
 
 t_p(t)=precision;
 t_r(t)=recall;
 t_F1(t)=F1;
end
STD=std(t_acc);
Acc=mean(t_acc);
T=mean(Time);

 pre=mean(t_p)*100;
 rec=mean(t_r)*100;
 F1=mean(t_F1)*100;




  


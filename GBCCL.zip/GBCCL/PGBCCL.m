%% 按照决策分裂粒球（非严格意义粒球）

%导入数据

%clear;clc

load wine.mat;data=wiscon;
[n_row,n_col] = size(data);

%% 鍒掑垎娴嬭瘯闆嗗拰璁粌闆?
[n_row,n_col]=size(data); %m代表属性个数
label=unique(data(:,n_col));%元素去重。即”删除”序列中所有相邻的重复元素(只保留一个)。此处的删除，并不是真的删除，而是指重复元素的位置被不重复的元素给占领了(
 data(:,1:n_col-1)=mapminmax(data(:,1:n_col-1)',0,1)'; %归一化处理模糊-经典形式背景
C=length(label); %类别个数
indices = crossvalind('Kfold',n_row,10);
tic;
for t=1:10
    tic;
    k_=t;
test=(indices==k_);
train=~test;
train_data=data(train,:);
datatest = data(test,:);
test=datatest(:,1:end-1);

F =train_data;%璁粌闆?
[row,column]=size(F);
x_label=unique(F(:,end));
p = size(x_label,1);
labeli= F(:,end);
%% 对象粒概念，属性粒概念
T=0;  tic;
x_intent=[];x_ex=zeros(row,row);%a_intent=[];a_ex=cell(column-1,1);
x_intent=F(:,1:end-1);%对象粒内涵
pur=zeros(1,row);
for i=1:row
     B = repmat(x_intent(i,:)',1,row);
     s = B'-x_intent;
     x_ex(i,find(all(s'<=0)))=1 ;%对象粒外延
     l_con=labeli(find(all(s'<=0)));
     pur(i)=length(find(l_con==mode(l_con)))/length(l_con);
    
end
L=zeros(row,p);
for i=1:p
    L(find(labeli==i),i)=1;
end

% for i=1:column-1
%      a_ex{i}= find(x_intent(:,i)>0);%属性粒外延
%       if length(a_ex{i})>1
%             a_intent(i,:)=min(x_intent(a_ex{i},:)); %属性粒内涵
%             %Bf{i}(j,:)=min(Ac{i}(X{i,j},1:m0-1)); 
%         else  
%             a_intent(i,:)=x_intent(a_ex{i},:); 
%             %Bf{i}(j,:)=Ac{i}(X{i,j},1:m0-1); 
%       end
% end
%G_ex={x_ex,a_ex};G_intent=[x_intent;a_intent];
%% 判断纯度



       fenlie=find(pur<1);
       gengxin=x_ex(fenlie,:);
       gbs=[];
       for i=1:length(fenlie)
          cun=repmat(gengxin(i,:),p,1)+L';
          cun(find(cun<2))=0;cun(find(cun==2))=1;
         gbs=[gbs;cun];
         
       end
       gbs(all(gbs==0,2),:)=[];
       x_ex(fenlie,:)=[];
       x_ex=[gbs;x_ex];
%        row_ex=length(x_ex(:,1));
        biaoji=x_ex*L;
%         ind=ones(row_ex,1);
%        for i=1:row_ex
%            if length(find(biaoji(i,:)>0))>1;
%               ind(i)=0;
%            end
%        end
% biaoji=biaoji.*ind;x_ex=x_ex.*ind;x_ex(all(x_ex==0,2),:)=[];biaoji(all(biaoji==0,2),:)=[];
 for i=1:length(x_ex(:,1))
    label_end(i)=find(biaoji(i,:)>0);
      if sum(x_ex(i,:))>1
            intent_end(i,:)=min(x_intent(find(x_ex(i,:)==1),:)); %属性粒内涵
            %Bf{i}(j,:)=min(Ac{i}(X{i,j},1:m0-1)); 
        else  
           
            intent_end(i,:)=x_intent(find(x_ex(i,:)==1),:);
            %Bf{i}(j,:)=Ac{i}(X{i,j},1:m0-1); 
      end
end

[na,~]=size(datatest);%time=10;
label_true =datatest (:,end);predict_label= [];%dis=[];

d1=[];
 for i=1:na 
     d1=pdist2(test(i,:),intent_end,'euclidean');sigma=median(d1);
     K=exp(-pdist2(test(i,:),intent_end,'euclidean').^2/(2*sigma^2));
     c2=find(K==max(K));
         
        % c2=find(d1==min(d1));
      

     predict_label(i,1)=label_end(c2(1));
 end
pre_true = length(find((predict_label)==label_true));
accuracy= (pre_true/na)*100;
 toc;T=T+toc;

Time(t)=toc;

 M=confusionmat(label_true,predict_label);
 precision=diag(M)./(sum(M,2));
 recall=diag(M)./(sum(M,1))';
 precision=mean(precision);
 recall=mean(recall);
 F1=2*(precision*recall)/(precision+recall);
 t_acc(t)=accuracy; 
 
 t_p(t)=precision;
 t_r(t)=recall;
 t_F1(t)=F1;
end
STD=std(t_acc);
Acc=mean(t_acc);
T=mean(Time);

 pre=mean(t_p)*100;
 rec=mean(t_r)*100;
 F1=mean(t_F1)*100;






